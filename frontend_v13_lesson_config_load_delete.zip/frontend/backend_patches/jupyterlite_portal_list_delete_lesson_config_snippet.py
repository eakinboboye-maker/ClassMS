# Add these routes to the backend file that owns the /api/jupyterlite router,
# usually: app/api/jupyterlite_portal.py
#
# They are required by the Vercel teacher dashboard page /lesson-configs.
# If your router is included with prefix="/api/jupyterlite", these decorators
# become:
#   GET    /api/jupyterlite/lesson-configs
#   DELETE /api/jupyterlite/lesson-config/{lesson_slug}

@router.get("/lesson-configs")
def list_lesson_launch_configs(
    db: Session = Depends(get_db),
    _: User = Depends(require_role("admin", "instructor")),
):
    rows = (
        db.query(LessonLaunchConfig)
        .order_by(LessonLaunchConfig.course_code.asc(), LessonLaunchConfig.lesson_slug.asc())
        .all()
    )
    return {"items": [_serialize_config(row) for row in rows]}


@router.delete("/lesson-config/{lesson_slug}")
def delete_lesson_launch_config(
    lesson_slug: str,
    db: Session = Depends(get_db),
    _: User = Depends(require_role("admin", "instructor")),
):
    row = (
        db.query(LessonLaunchConfig)
        .filter(LessonLaunchConfig.lesson_slug == lesson_slug)
        .first()
    )
    if not row:
        raise HTTPException(status_code=404, detail="Lesson config not found")

    db.delete(row)
    db.commit()
    return {
        "status": "deleted",
        "lesson_slug": lesson_slug,
        "message": "Lesson launch config deleted. Course, assessment, notebook, questions, attempts, and scores were not deleted.",
    }
